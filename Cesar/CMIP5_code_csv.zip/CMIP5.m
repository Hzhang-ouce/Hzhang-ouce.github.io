% clc
% clear
% addpath E:\huanyuan\Trendy_file\code
%
% %%
% cd E:\huanyuan\CMIP5
% File = dir('*.nc');
% FileName = {File.name}';
% FileName_cSoil = FileName(1:end/2);
% FileName_cVeg = FileName(end/2+1:end);
% Model = cell(length(FileName)/2,1);
% for ii = 1:length(FileName)/2
%     Model{ii} = FileName_cSoil{ii}(12:end-36);
% end
%
% %%
% yyyymm = cell(2021*12,1);
% for ii = 0:2020
%     for jj = 1:12
%         yyyymm{ii*12+jj} = [num2str(ii,'%04d'),num2str(jj,'%02d')];
%     end
% end
%
% %%
% OUTPUT = cell(length(FileName_cSoil),4);
% for ii = 1:length(FileName_cSoil)
%     cSoil_in = ncread(FileName_cSoil{ii},'cSoil');
%     yyyymm_start = FileName_cSoil{ii}(end-15:end-10);
%     yyyymm_end = FileName_cSoil{ii}(end-8:end-3);
%     yyyymm_array = yyyymm(find(strcmp(yyyymm,yyyymm_start)):find(strcmp(yyyymm,yyyymm_end)));
%     load(['Area_WGS_1984_',num2str(size(cSoil_in,1)),'_',num2str(size(cSoil_in,2)),'.mat']);
%     cSoil_out = nan(length(yyyymm_array),1);
%     for jj = 1:length(yyyymm_array)
%         cSoil_out(jj) = nansum(nansum(cSoil_in(:,:,jj).*Area_WGS_1984'));
%     end
%     OUTPUT{ii,1} = cSoil_out;
%     OUTPUT{ii,2} = yyyymm_array;
% end
%
% %%
% for ii = 1:length(FileName_cVeg)
%     try
%         cVeg_in = ncread(FileName_cVeg{ii},'cVeg');
%         yyyymm_start = FileName_cVeg{ii}(end-15:end-10);
%         yyyymm_end = FileName_cVeg{ii}(end-8:end-3);
%         yyyymm_array = yyyymm(find(strcmp(yyyymm,yyyymm_start)):find(strcmp(yyyymm,yyyymm_end)));
%         load(['Area_WGS_1984_',num2str(size(cVeg_in,1)),'_',num2str(size(cVeg_in,2)),'.mat']);
%         cVeg_out = nan(length(yyyymm_array),1);
%         for jj = 1:length(yyyymm_array)
%             cVeg_out(jj) = nansum(nansum(cVeg_in(:,:,jj).*Area_WGS_1984'));
%         end
%         OUTPUT{ii,3} = cVeg_out;
%         OUTPUT{ii,4} = yyyymm_array;
%     catch
%     end
% end
% Line1 = {'cSoil','yyyymm','cVeg','yyyymm'};
% save OUTPUT OUTPUT Line1 Model
%
% %%
% model_unique = unique(Model);
% loc = nan(7,1);
% for ii = 1:7
%     loc(ii) = find(strcmp(model_unique(ii),Model),1,'first');
% end
% OUTPUT_final = cell(7,4);
% for ii = [1 2 5]
%     OUTPUT_final(ii,:) = OUTPUT(loc(ii),:);
% end
% for ii = [3 4 6 7]
%     try
%         temp = OUTPUT(loc(ii):loc(ii+1)-1,1);
%     catch
%         temp = OUTPUT(loc(ii):end,1);
%     end
%     final=[];
%     for jj = 1:length(temp)
%         final = [final;temp{jj}];
%     end
%     OUTPUT_final{ii,1} = final;
%     
%     try
%         temp = OUTPUT(loc(ii):loc(ii+1)-1,2);
%     catch
%         temp = OUTPUT(loc(ii):end,2);
%     end
%     final=[];
%     for jj = 1:length(temp)
%         final = [final;temp{jj}];
%     end
%     OUTPUT_final{ii,2} = final;
%     
%     try
%         temp = OUTPUT(loc(ii):loc(ii+1)-1,3);
%     catch
%         temp = OUTPUT(loc(ii):end,3);
%     end
%     final=[];
%     for jj = 1:length(temp)
%         final = [final;temp{jj}];
%     end
%     OUTPUT_final{ii,3} = final;
%     
%     try
%         temp = OUTPUT(loc(ii):loc(ii+1)-1,4);
%     catch
%         temp = OUTPUT(loc(ii):end,4);
%     end
%     final=[];
%     for jj = 1:length(temp)
%         final = [final;temp{jj}];
%     end
%     OUTPUT_final{ii,4} = final;
% end
% 
% save OUTPUT_final OUTPUT_final Line1 model_unique

%%
clc
clear
load OUTPUT_final
yyyymm=[];
for ii = 1:7
    yyyymm = [yyyymm;OUTPUT_final{ii,2}];
end

cSoil = cell2mat(OUTPUT_final(:,1));
cVeg = cell2mat(OUTPUT_final(:,3));

xlswrite('E:\huanyuan\Assignment4\CMIP5.xlsx',{'yyyymm','cSoil','cVeg'},'Sheet1','A1');
xlswrite('E:\huanyuan\Assignment4\CMIP5.xlsx',yyyymm,'Sheet1','A2');
xlswrite('E:\huanyuan\Assignment4\CMIP5.xlsx',cSoil,'Sheet1','B2');
xlswrite('E:\huanyuan\Assignment4\CMIP5.xlsx',cVeg,'Sheet1','C2');





