clc
clear
close all
cd F:\Cesar_project_csoil
Input_data=readtable('For_CESAR.csv'); %I just copy and paste the columns for annual sum into another CSV file and named For_CESAR.csv
List_of_model=unique(Input_data.model);
Output=table(List_of_model,(1:length(List_of_model))',(1:length(List_of_model))',(1:length(List_of_model))',(1:length(List_of_model))','VariableNames',{'Model_unit_PgC','a372ppm_Csoil','a616ppm_Csoil','a372ppm_Cveg','a616ppm_Cveg'});
for ii=1:length(List_of_model)
    model_name=List_of_model{ii};
    Our_interest=Input_data(strcmp(Input_data.model,model_name),:); 
    %Some of the model started from 1850, some from 1860, some from 0001,
    %so whatever, lets assume first year is 285ppm, so 372ppm should be
    %year 28. amd 616ppm should be year 78 (well, if they do increase by 1%
    %every year, now I know GFDL-ESM2M did not, they increase too slow, and
    %CESM1-BGC is even decreasing)
    Output{ii,'a372ppm_Csoil'}=nanmean(Our_interest{25:31,'cSoil'});
    Output{ii,'a616ppm_Csoil'}=nanmean(Our_interest{75:81,'cSoil'});
    Output{ii,'a372ppm_Cveg'}=nanmean(Our_interest{25:31,'cVeg'});
    Output{ii,'a616ppm_Cveg'}=nanmean(Our_interest{75:81,'cVeg'});
    
end
Output.delta_Csoil=Output.a616ppm_Csoil-Output.a372ppm_Csoil;
Output.delta_Cveg=Output.a616ppm_Cveg-Output.a372ppm_Cveg;

%writetable(Output,"CMIP5_esmFixClim1_cveg_csoil.csv")