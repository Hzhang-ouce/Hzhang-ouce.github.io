clc
clear
addpath E:\huanyuan\Trendy_file\code

%%
cd E:\huanyuan\CMIP5\co2
File = dir('*.nc');
FileName = {File.name}';
Model = cell(length(FileName),1);
for ii = 1:length(FileName)
    Model{ii} = FileName{ii}(10:end-36);
end

%%
yyyymm = cell(2021*12,1);
for ii = 0:2020
    for jj = 1:12
        yyyymm{ii*12+jj} = [num2str(ii,'%04d'),num2str(jj,'%02d')];
    end
end

%%
OUTPUT = cell(length(FileName),2);
for ii = 1:length(FileName)
    info = ncinfo(FileName{ii});
    loc = find(strcmp({info.Variables.Name},'co2'));
    Size = {info.Variables.Size};
    count = Size{loc};
    count(3) = 1;
    co2_in = ncread(FileName{ii},'co2',[1 1 1 1],count);
    co2_in = reshape(co2_in,count(1),count(2),count(4));
    yyyymm_start = FileName{ii}(end-15:end-10);
    yyyymm_end = FileName{ii}(end-8:end-3);
    yyyymm_array = yyyymm(find(strcmp(yyyymm,yyyymm_start)):find(strcmp(yyyymm,yyyymm_end)));
%     load(['Area_WGS_1984_',num2str(size(co2_in,1)),'_',num2str(size(co2_in,2)),'.mat']);
    co2_out = nan(length(yyyymm_array),1);
    for jj = 1:length(yyyymm_array)
        co2_out(jj) = nanmean(nanmean(co2_in(:,:,jj)));
    end
    OUTPUT{ii,1} = co2_out;
    OUTPUT{ii,2} = yyyymm_array;
end
Line1 = {'co2','yyyymm'};
save OUTPUT OUTPUT Line1 Model

%%
load OUTPUT
model_unique = unique(Model);
loc = nan(length(model_unique),1);
for ii = 1:length(model_unique)
    loc(ii) = find(strcmp(model_unique(ii),Model),1,'first');
end
OUTPUT_final = cell(length(model_unique),2);
for ii = 2
    OUTPUT_final(ii,:) = OUTPUT(loc(ii),:);
end
for ii = [1 3 4]
    try
        temp = OUTPUT(loc(ii):loc(ii+1)-1,1);
    catch
        temp = OUTPUT(loc(ii):end,1);
    end
    final=[];
    for jj = 1:length(temp)
        final = [final;temp{jj}];
    end
    OUTPUT_final{ii,1} = final;
    
    try
        temp = OUTPUT(loc(ii):loc(ii+1)-1,2);
    catch
        temp = OUTPUT(loc(ii):end,2);
    end
    final=[];
    for jj = 1:length(temp)
        final = [final;temp{jj}];
    end
    OUTPUT_final{ii,2} = final;
    
end

save OUTPUT_final OUTPUT_final Line1 model_unique

%%
clc
clear
load OUTPUT_final
yyyymm=[];
for ii = 1:size(OUTPUT_final,1)
    yyyymm = [yyyymm;OUTPUT_final{ii,2}];
end

co2 = cell2mat(OUTPUT_final(:,1));

for ii = 1:length(co2)/12
    a(ii) = nanmean(nanmean(co2(ii*12-11:ii*12)));
end
a=a';





